package com.fzplayer.media;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private static final int PERMISSION_REQUEST_CODE = 101;
    public static final int FILE_CHOOSER_REQUEST_CODE = 1002;

    private ValueCallback<Uri[]> mUploadCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().setStatusBarColor(0xFF090A10);
            getWindow().setNavigationBarColor(0xFF090A10);
        }

        webView = new WebView(this);
        setContentView(webView);

        // Modern WebViewAssetLoader securely serves local assets on https://appassets.androidplatform.net
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .setDomain("appassets.androidplatform.net")
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/res/", new WebViewAssetLoader.ResourcesPathHandler(this))
                .build();

        setupWebView(assetLoader);
        checkAndRequestPermissions();

        // Load app entry point
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private void setupWebView(final WebViewAssetLoader assetLoader) {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        WebView.setWebContentsDebuggingEnabled(true);

        // Native Android Bridge to trigger scanning from Web UI
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void scanLocalAudio() {
                scanLocalAudioFiles();
            }

            @JavascriptInterface
            public boolean isAndroid() {
                return true;
            }
        }, "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    if (uri.getHost() != null && uri.getHost().contains("appassets.androidplatform.net")) {
                        return false;
                    }
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                        return true;
                    } catch (Exception ignored) {}
                }
                return false;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                String path = url.getPath();

                // Intercept direct local audio playback
                if (path != null && (path.startsWith("/local-audio/") || path.contains("local-audio/"))) {
                    try {
                        String idStr = path.substring(path.lastIndexOf('/') + 1);
                        long id = Long.parseLong(idStr);
                        Uri contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
                        InputStream is = getContentResolver().openInputStream(contentUri);
                        if (is != null) {
                            return new WebResourceResponse("audio/mpeg", "UTF-8", is);
                        }
                    } catch (Exception ignored) {}
                }

                // 1. Delegate to WebViewAssetLoader
                WebResourceResponse response = assetLoader.shouldInterceptRequest(url);
                if (response != null) {
                    return response;
                }

                // 2. Custom fallback interceptor for all relative/absolute asset paths
                if (path != null) {
                    String cleanPath = path.startsWith("/") ? path.substring(1) : path;
                    if (cleanPath.startsWith("assets/")) {
                        cleanPath = cleanPath.substring("assets/".length());
                    }

                    try {
                        InputStream is = getAssets().open(cleanPath);
                        String mimeType = getMimeType(cleanPath);
                        return new WebResourceResponse(mimeType, "UTF-8", is);
                    } catch (Exception ignored) {
                        try {
                            InputStream is2 = getAssets().open("assets/" + cleanPath);
                            String mimeType = getMimeType(cleanPath);
                            return new WebResourceResponse(mimeType, "UTF-8", is2);
                        } catch (Exception ignored2) {}
                    }
                }

                return null;
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                if (failingUrl != null && failingUrl.contains("appassets.androidplatform.net") && failingUrl.endsWith("index.html")) {
                    view.loadUrl("file:///android_asset/index.html");
                }
            }
        });

        // WebChromeClient with onShowFileChooser for Gallery and File selection
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                request.grant(request.getResources());
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                return super.onConsoleMessage(consoleMessage);
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams) {
                if (mUploadCallback != null) {
                    mUploadCallback.onReceiveValue(null);
                    mUploadCallback = null;
                }
                mUploadCallback = filePathCallback;

                Intent intent = null;
                try {
                    intent = fileChooserParams.createIntent();
                    if (fileChooserParams.getAcceptTypes() != null && fileChooserParams.getAcceptTypes().length > 0) {
                        String mime = fileChooserParams.getAcceptTypes()[0];
                        if (mime != null && !mime.isEmpty()) {
                            intent.setType(mime);
                        }
                    }
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                }

                try {
                    startActivityForResult(Intent.createChooser(intent, "Select Picture or Media"), FILE_CHOOSER_REQUEST_CODE);
                    return true;
                } catch (Exception e) {
                    if (mUploadCallback != null) {
                        mUploadCallback.onReceiveValue(null);
                        mUploadCallback = null;
                    }
                    return false;
                }
            }
        });

        webView.setBackgroundColor(0xFF090A10);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (mUploadCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            mUploadCallback.onReceiveValue(results);
            mUploadCallback = null;
        }
    }

    /**
     * Scans all local downloaded audio files from phone storage via MediaStore
     * and passes them directly to the Web interface.
     */
    public void scanLocalAudioFiles() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final JSONArray jsonArray = new JSONArray();
                    ContentResolver resolver = getContentResolver();
                    Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
                    String sortOrder = MediaStore.Audio.Media.TITLE + " ASC";

                    String[] projection = {
                            MediaStore.Audio.Media._ID,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST,
                            MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.DURATION,
                            MediaStore.Audio.Media.DATA,
                            MediaStore.Audio.Media.SIZE
                    };

                    Cursor cursor = resolver.query(uri, projection, selection, null, sortOrder);
                    if (cursor != null) {
                        int idCol = cursor.getColumnIndex(MediaStore.Audio.Media._ID);
                        int titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
                        int artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                        int albumCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                        int durationCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                        int dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                        int sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE);

                        while (cursor.moveToNext()) {
                            long id = idCol != -1 ? cursor.getLong(idCol) : 0;
                            String title = titleCol != -1 ? cursor.getString(titleCol) : "";
                            String artist = artistCol != -1 ? cursor.getString(artistCol) : "";
                            String album = albumCol != -1 ? cursor.getString(albumCol) : "";
                            long durationMs = durationCol != -1 ? cursor.getLong(durationCol) : 0;
                            String data = dataCol != -1 ? cursor.getString(dataCol) : "";
                            long size = sizeCol != -1 ? cursor.getLong(sizeCol) : 0;

                            JSONObject obj = new JSONObject();
                            obj.put("id", "android-media-" + id);
                            obj.put("title", (title != null && !title.trim().isEmpty()) ? title : "Audio Track");
                            obj.put("artist", (artist != null && !artist.equals("<unknown>") && !artist.trim().isEmpty()) ? artist : "Device Storage");
                            obj.put("album", (album != null && !album.equals("<unknown>") && !album.trim().isEmpty()) ? album : "Local Music");
                            obj.put("duration", Math.max(1, (int)(durationMs / 1000)));
                            obj.put("audioUrl", "https://appassets.androidplatform.net/local-audio/" + id);
                            obj.put("filePath", data != null ? data : "");
                            obj.put("fileSize", String.format("%.1f MB", size / (1024.0 * 1024.0)));
                            obj.put("fileFormat", "MP3");
                            obj.put("hasMV", false);
                            obj.put("genre", "Local Music");
                            obj.put("isFavorite", false);
                            obj.put("playCount", 0);
                            obj.put("dateAdded", System.currentTimeMillis());
                            obj.put("folder", "Device Storage / Music");
                            obj.put("artworkUrl", "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80");

                            jsonArray.put(obj);
                        }
                        cursor.close();
                    }

                    final String payload = jsonArray.toString();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            webView.evaluateJavascript("if (window.onAndroidLocalTracksScanned) { window.onAndroidLocalTracksScanned(" + payload + "); }", null);
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private String getMimeType(String path) {
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".js") || path.endsWith(".mjs")) return "application/javascript";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".jpg") || path.endsWith(".jpeg")) return "image/jpeg";
        if (path.endsWith(".svg")) return "image/svg+xml";
        if (path.endsWith(".json")) return "application/json";
        if (path.endsWith(".mp3")) return "audio/mpeg";
        if (path.endsWith(".mp4")) return "video/mp4";
        return "application/octet-stream";
    }

    private void checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            boolean audioGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED;
            boolean videoGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED;
            boolean imagesGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;

            if (!audioGranted || !videoGranted || !imagesGranted) {
                ActivityCompat.requestPermissions(this, new String[]{
                        Manifest.permission.READ_MEDIA_AUDIO,
                        Manifest.permission.READ_MEDIA_VIDEO,
                        Manifest.permission.READ_MEDIA_IMAGES
                }, PERMISSION_REQUEST_CODE);
            } else {
                scanLocalAudioFiles();
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE
                }, PERMISSION_REQUEST_CODE);
            } else {
                scanLocalAudioFiles();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean anyGranted = false;
            for (int res : grantResults) {
                if (res == PackageManager.PERMISSION_GRANTED) {
                    anyGranted = true;
                    break;
                }
            }
            if (anyGranted) {
                scanLocalAudioFiles();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
